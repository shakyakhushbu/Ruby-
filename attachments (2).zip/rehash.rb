# a = ["Satyam","Amisha"]
# b = ["Nikhil","Saksham"]

# hsh = {a=>"friends", b=>"friends"}

# puts "Hash elements are: #{hsh}"

# puts "Hash.rehash implementation"

# b[0]="Hrithik"

# puts "Hash after rehash: #{hsh.rehash}"


h1 =  {[a,b]:10,[c,d]:9}
puts h1