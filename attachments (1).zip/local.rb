# name = "Khushbu"
# def met
#     name = 10
#     puts "#{name}"
# end
# met
# puts "#{name}"

# name = 10
# def met
#     name = "Khushbu"
#     puts "#{name}"
# end
# met

# a = 0 
# for i in 2..10
#     puts a
# end

#It will be accessible here because for doesnt use do and end its not a block

#     a = 0
# 3.times do 

#     puts a 
# end

# for i in 1..10
#     a  = "Khushbbu"
#     # puts a 
# end
# puts a

# def met
#     a = "Khushbu"
#     puts a 
# end
# met
# puts a

# def met(x)
#     puts x
# end
# a = met(6)
# puts "#{a}"










name  = 10
def met 
    puts "{10}"
end
#Local variable is not accessible inside method






# def met 
#     x = 20
#     puts x
# end
# met
# puts x
#A local var defined in method is not accessible


# for i in 1..10
#     a = 10
#     # puts a 
# end
# puts a
#It is accessible outside loops



# a = 10
# 2.times do 
    
#     puts a
# end
#If we define local before any block then it is accessible 



# 2.times do 
#     puts a
# end
# a = 10
#f we define local before any block then it is not accessible



# 2.times do 
#     x = 10
#     puts x
# end
# puts x
#if a variable is defined inside a block it is not accessible