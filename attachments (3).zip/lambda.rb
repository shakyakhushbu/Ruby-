adds_one = -> a { puts a + 1 }
adds_one.call(1)
# or 
adds_one = lambda {|num,v| puts num*v}
adds_one.call(20,49)