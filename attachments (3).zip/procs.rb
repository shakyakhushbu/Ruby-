# square = Proc.new{|n| puts n*3}
# square.call(5)

# def met(&square)
#     puts "This is method"
#     block.call
    
# end
# met = Proc.new{|num| puts num*5}
# puts met.class 
# def square(&square)
#     block.call(5)
# end
# square = Proc.new{|n| puts n*6}
# square.call(7)

# proc_object1=proc{puts "This is another object"}
# proc_object = Proc.new {puts "This is code"}
# # Here proc is converting a block into proc object
# proc_object.call
# puts proc_object.lambda?
# proc_object1.call
#simple ways to create a proc


# proc_object = Proc.new{|n| puts "Khushbu" * n}
# proc_object.call(6)
# proc_object = Proc.new{|n| puts "Khushbu" * n}.call(8)
# proc_object = Proc.new{|n| puts "Khushbu" * n}.(6)
# proc_object = Proc.new{|n| puts "Khushbu" * n}[2]

# def run_proc_with_random_number(proc)
#     proc.call(3)
#   end
   
#   proc = Proc.new { |n| puts "#{n}" }
#   run_proc_with_random_number(proc)



# proc = Proc.new {puts "This is a proc"}

# def proc_object(proc)
#     proc.call
# end
# proc_object(proc)


# def run_proc_with_random_number(&block)
#     block.call(7)
# end
   
# arr = run_proc_with_random_number { |n| puts "#{n}!" }


#how procs are different from blocks


# proc = Proc.new {|num| puts "This is a numebr"}
# def met(proc)
#     proc.call 
# end
# met(proc)
# here it ignored the number of arguments

# proc = lambda {|num| puts "This is a numebr"}
# def met(proc)
#     proc.call 
# end
# met(proc)

# proc = -> {|num| puts "This is a numebr"}
# def met(proc)
#     proc.call 
# end
# met(proc)

adds_two = Proc.new { |x|puts x + 2 }
adds_two.call(2,2,3)